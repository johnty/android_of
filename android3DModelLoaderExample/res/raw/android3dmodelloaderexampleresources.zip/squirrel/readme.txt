-- 3dvia.com   --

The zip file NewSquirrel.3ds.zip contains the following files :
- readme.txt
- NewSquirrel.3ds
- Squirrel.jpg


-- Model information --

Model Name : New Squirrel
Author : Bruce Lehmann
Publisher : Omind

You can view this model here :
http://www.3dvia.com/Omind/media/64EAC75A6C7E5062
More models about this author :
http://www.3dvia.com/Omind


-- Attached license --

A license is attached to the New Squirrel model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailled license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
